$(document).ready(function() {
    var slider = $("#light-slider").lightSlider({
       autoWidth: true,
       slideMove: 1, // slidemove will be 1 if loop is true
       controls: false,
       loop:true,
       
    });
    $('.slideControls .slidePrev').click(function() {
        slider.goToPrevSlide();
    });

    $('.slideControls .slideNext').click(function() {
        slider.goToNextSlide();
    });

// new slide control
var slider2 = $("#light-slider-2").lightSlider({
    autoWidth: true,
    slideMove: 1, // slidemove will be 1 if loop is true
    controls: false,
    loop:true,
    });
    $('.slideControls2 .slidePrev').click(function() {
        slider2.goToPrevSlide();
    });

    $('.slideControls2 .slideNext').click(function() {
        slider2.goToNextSlide();
    });
  // new slide control 


var slider3 = $("#light-slider-3").lightSlider({
    autoWidth: true,
    slideMove: 1, // slidemove will be 1 if loop is true
    controls: false,
    loop:true,
    });
    $('.slideControls3 .slidePrev').click(function() {
        slider3.goToPrevSlide();
    });

    $('.slideControls3 .slideNext').click(function() {
        slider3.goToNextSlide();
    });
  // new slide control 

});